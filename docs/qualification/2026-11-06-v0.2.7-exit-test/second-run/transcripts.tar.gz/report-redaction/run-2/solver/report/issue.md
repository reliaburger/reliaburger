<!-- drafted by relish agent report; a human reads it and posts it -->

### Fingerprint

None: no error code, finding or site was given (seen on 0.2.7).

### Version

relish 0.2.7, commit eca6c2d2f47563428e94a1dbc5948e7758d56860, source as committed, aarch64-apple-darwin, formats protocol 57 / state 73

### Fix status

Not known: the agent didn't find a release with the fix.

### What happened

App default/payments (1 replica on node gym-1, running, healthy, 0 restarts) keeps failing calls to its upstream. Log lines: 'payments: POST https://ipv4-1/charge failed: 401 Unauthorized'; 'payments: sent Authorization: Bearer rbrg_[redacted] to ipv4-1'; 'payments: retried with Authorization: Bearer eyJ[redacted]'; 'payments: db connect failed: host=db user=payments password=[redacted]'; 'payments: upstream config API_KEY=[redacted]'; 'payments: will retry in 30s'; 'testapp: listening on 0.0.0.0:31404 (mode: healthy)'. Configuration: namespace default, desired 1 / running 1, placed on gym-1, service VIP 127.128.19.8 port 31404 with 1/1 healthy backend (host port 31898), one completed deploy, no ingress routes. relish agent diagnose reports no findings (replicas, services, crashloops, deploys OK).

Expected: The upstream call succeeds, or relish surfaces a Reliaburger-side cause. The 401 comes from the upstream rejecting the app's credentials, which points at app/upstream credentials rather than Reliaburger.

### Reproducer

None. This report is **unverified**: nobody has made it happen on purpose yet.

### Evidence

```shell
{
  "evidence": [],
  "fingerprint": null,
  "patch": null,
  "relish": {
    "commit": "eca6c2d2f47563428e94a1dbc5948e7758d56860",
    "dirty": false,
    "formats": {
      "protocol": 57,
      "state": 73
    },
    "target": "aarch64-apple-darwin",
    "version": "0.2.7"
  },
  "schema": "relish.agent.report/v1"
}
```

### Suspected source

None.

### Patch

None.

### What was not tested

App manifest env/secrets not read (read-only token); upstream logs and credential validity not checked; no exec into the instance; no reproducer.

### How this should have been caught

Not known yet.

### Redaction

Addresses aliased; log lines left out. From `MANIFEST.json`, what went in and what redaction took out:

| Item | Bytes | In | Redacted |
|---|---:|---|---|
| field `title` | 67 | yes | none |
| field `what_happened` | 808 | yes | ipv4_address 2 |
| field `expected` | 203 | yes | none |
| field `not_tested` | 145 | yes | none |

### AI assistance

An AI agent drafted it, and a human checked every line

### Human review

- [ ] I'm a human, I read this whole report and I answer for it.
- [ ] I checked the redaction manifest and nothing private is left.
- [ ] I searched the issues for the fingerprint.
