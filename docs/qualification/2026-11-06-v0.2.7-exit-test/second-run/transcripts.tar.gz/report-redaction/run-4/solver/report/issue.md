<!-- drafted by relish agent report; a human reads it and posts it -->

### Fingerprint

None: no error code, finding or site was given (seen on 0.2.7).

### Version

relish 0.2.7, commit eca6c2d2f47563428e94a1dbc5948e7758d56860, source as committed, aarch64-apple-darwin, formats protocol 57 / state 73

### Fix status

Not known: the agent didn't find a release with the fix.

### What happened

App default/payments (1/1 replicas running on gym-1, 0 restarts, service port 31404) repeatedly fails its upstream call: POST https://<upstream>/charge returns 401 Unauthorized. App logs: sent a Bearer API token, retried with a different JWT-style Bearer token, db connect failed (host=db user=payments, password redacted), upstream config API_KEY (redacted), will retry in 30s. Configuration seen: 1 desired replica on gym-1, service port 31404, one completed deploy with no image recorded. relish agent diagnose shows no findings for the app (replicas, services, deploys, crashloops OK). Unrelated cluster warnings: registry-needs-mtls, Pickle degraded on gym-1.

Expected: The upstream accepts the app's credentials, or Reliaburger reports why, if it is interfering with the request or with secret injection.

### Reproducer

None. This report is **unverified**: nobody has made it happen on purpose yet.

### Evidence

```shell
{
  "evidence": [],
  "fingerprint": null,
  "patch": null,
  "relish": {
    "commit": "eca6c2d2f47563428e94a1dbc5948e7758d56860",
    "dirty": false,
    "formats": {
      "protocol": 57,
      "state": 73
    },
    "target": "aarch64-apple-darwin",
    "version": "0.2.7"
  },
  "schema": "relish.agent.report/v1"
}
```

### Suspected source

None.

### Patch

None.

### What was not tested

Could not read the app manifest, env or secrets (read-only token; audit needs admin). Did not exec into the instance, check the upstream's logs, or confirm secrets are decrypted and injected correctly. No reproducer.

### How this should have been caught

Not known yet.

### Redaction

Addresses aliased; log lines left out. From `MANIFEST.json`, what went in and what redaction took out:

| Item | Bytes | In | Redacted |
|---|---:|---|---|
| field `title` | 101 | yes | none |
| field `what_happened` | 664 | yes | none |
| field `expected` | 135 | yes | none |
| field `not_tested` | 216 | yes | none |

### AI assistance

An AI agent drafted it, and a human checked every line

### Human review

- [ ] I'm a human, I read this whole report and I answer for it.
- [ ] I checked the redaction manifest and nothing private is left.
- [ ] I searched the issues for the fingerprint.
