<!-- drafted by relish agent report; a human reads it and posts it -->

### Fingerprint

None: no error code, finding or site was given (seen on 0.2.7).

### Version

relish 0.2.7, commit eca6c2d2f47563428e94a1dbc5948e7758d56860, source as committed, aarch64-apple-darwin, formats protocol 57 / state 73

### Fix status

Not known: the agent didn't find a release with the fix.

### What happened

App default/payments (1 replica on node gym-1, state running, 0 restarts, service port 31404, service VIP 1/1 backends healthy, deploy 1793988720 Completed) keeps failing calls to its upstream. Log lines (relish agent logs payments, already redacted at source):
payments: POST https://ipv4-1/charge failed: 401 Unauthorized
payments: sent Authorization: Bearer rbrg_[redacted] to ipv4-1
payments: retried with Authorization: Bearer eyJ[redacted]
payments: db connect failed: host=db user=payments password=[redacted]
payments: upstream config API_KEY=[redacted]
payments: will retry in 30s
testapp: listening on 0.0.0.0:31404 (mode: healthy)
Configuration learned: namespace default, 1 desired replica, placed on gym-1, service port 31404, host port 20571; the app is set up with an upstream API_KEY and a db host 'db' with user 'payments'. It sends an rbrg_[redacted]-prefixed Bearer token, then a JWT-style one, and gets 401 both times. relish agent diagnose --app payments: no findings (crashloops, deploys, replicas, services ok). A transient placement warning ('no node is ready') cleared 4s later. Cluster warnings registry-needs-mtls and registry-redundancy don't involve this path.

Expected: The upstream accepts the app's credentials, or Reliaburger shows a finding if it causes the auth failure (for example, a secret injected wrong).

### Reproducer

None. This report is **unverified**: nobody has made it happen on purpose yet.

### Evidence

```shell
{
  "evidence": [],
  "fingerprint": null,
  "patch": null,
  "relish": {
    "commit": "eca6c2d2f47563428e94a1dbc5948e7758d56860",
    "dirty": false,
    "formats": {
      "protocol": 57,
      "state": 73
    },
    "target": "aarch64-apple-darwin",
    "version": "0.2.7"
  },
  "schema": "relish.agent.report/v1"
}
```

### Suspected source

None.

### Patch

None.

### What was not tested

Didn't check manifest env/secret values (read-only token; secrets redacted). Didn't exec into the instance, call the upstream directly, check what serves ipv4-1, or check that 'db' resolves. Couldn't list tokens (403). No reproducer.

### How this should have been caught

Not known yet.

### Redaction

Addresses aliased; log lines left out. From `MANIFEST.json`, what went in and what redaction took out:

| Item | Bytes | In | Redacted |
|---|---:|---|---|
| field `title` | 98 | yes | none |
| field `what_happened` | 1189 | yes | ipv4_address 2, reliaburger_token 1 |
| field `expected` | 144 | yes | none |
| field `not_tested` | 233 | yes | ipv4_address 1 |

### AI assistance

An AI agent drafted it, and a human checked every line

### Human review

- [ ] I'm a human, I read this whole report and I answer for it.
- [ ] I checked the redaction manifest and nothing private is left.
- [ ] I searched the issues for the fingerprint.
