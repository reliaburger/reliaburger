<!-- drafted by relish agent report; a human reads it and posts it -->

### Fingerprint

None: no error code, finding or site was given (seen on 0.2.7).

### Version

relish 0.2.7, commit eca6c2d2f47563428e94a1dbc5948e7758d56860, source as committed, aarch64-apple-darwin, formats protocol 57 / state 73

### Fix status

Not known: the agent didn't find a release with the fix.

### What happened

The payments app (default namespace, 1 replica on gym-1, running, 0 restarts, service port 31404, backend healthy) logs: POST https://ipv4-1/charge failed: 401 Unauthorized; it sent a Bearer rbrg_[redacted] token (redacted), retried with an eyJ JWT bearer (redacted), then db connect failed (host=db user=payments, password redacted); upstream config API_KEY (redacted); retries every 30s. diagnose shows no findings. Upstream is reached directly by IP over HTTPS, not through a service VIP.

Expected: The upstream accepts the app's configured credentials and /charge succeeds.

### Reproducer

None. This report is **unverified**: nobody has made it happen on purpose yet.

### Evidence

```shell
{
  "evidence": [],
  "fingerprint": null,
  "patch": null,
  "relish": {
    "commit": "eca6c2d2f47563428e94a1dbc5948e7758d56860",
    "dirty": false,
    "formats": {
      "protocol": 57,
      "state": 73
    },
    "target": "aarch64-apple-darwin",
    "version": "0.2.7"
  },
  "schema": "relish.agent.report/v1"
}
```

### Suspected source

None.

### Patch

None.

### What was not tested

App manifest, env and secrets not readable with a read-only token; did not exec in or reach ipv4-1; no reproducer.

### How this should have been caught

Not known yet.

### Redaction

Addresses aliased; log lines included, redacted. From `MANIFEST.json`, what went in and what redaction took out:

| Item | Bytes | In | Redacted |
|---|---:|---|---|
| field `title` | 63 | yes | none |
| field `what_happened` | 491 | yes | ipv4_address 1, reliaburger_token 1 |
| field `expected` | 75 | yes | none |
| field `not_tested` | 114 | yes | ipv4_address 1 |

### AI assistance

An AI agent drafted it, and a human checked every line

### Human review

- [ ] I'm a human, I read this whole report and I answer for it.
- [ ] I checked the redaction manifest and nothing private is left.
- [ ] I searched the issues for the fingerprint.
