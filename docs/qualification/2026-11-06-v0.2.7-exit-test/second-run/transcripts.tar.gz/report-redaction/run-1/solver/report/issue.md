<!-- drafted by relish agent report; a human reads it and posts it -->

### Fingerprint

None: no error code, finding or site was given (seen on 0.2.7).

### Version

relish 0.2.7, commit eca6c2d2f47563428e94a1dbc5948e7758d56860, source as committed, aarch64-apple-darwin, formats protocol 57 / state 73

### Fix status

Not known: the agent didn't find a release with the fix.

### What happened

App default/payments (1 replica on node gym-1, instance default__payments-0, running, 0 restarts, service_port 31404, host_port 29561). Log lines: 'payments: POST https://ipv4-1/charge failed: 401 Unauthorized'; 'payments: sent Authorization: Bearer rbrg_[redacted] to ipv4-1'; 'payments: retried with Authorization: Bearer eyJ[redacted]'; 'payments: db connect failed: host=db user=payments password=[redacted]'; 'payments: upstream config API_KEY=[redacted]'; 'payments: will retry in 30s'; 'testapp: listening on 0.0.0.0:31404 (mode: healthy)'. relish agent diagnose finds no crashloop, replica, deploy or service problem. Placement briefly failed with 'no node is ready' at startup, then succeeded.

Expected: The upstream call succeeds, or, if Reliaburger is at fault (e.g. how it injects the app's credentials), the platform shows that.

### Reproducer

None. This report is **unverified**: nobody has made it happen on purpose yet.

### Evidence

```shell
{
  "evidence": [],
  "fingerprint": null,
  "patch": null,
  "relish": {
    "commit": "eca6c2d2f47563428e94a1dbc5948e7758d56860",
    "dirty": false,
    "formats": {
      "protocol": 57,
      "state": 73
    },
    "target": "aarch64-apple-darwin",
    "version": "0.2.7"
  },
  "schema": "relish.agent.report/v1"
}
```

### Suspected source

None.

### Patch

None.

### What was not tested

Didn't check the app's manifest or secret values (read-only token, no exec), didn't confirm which credentials the upstream expects, and didn't reproduce it. The 401 comes from the upstream itself, so this is most likely an application credential problem, not a Reliaburger bug.

### How this should have been caught

Not known yet.

### Redaction

Addresses aliased; log lines left out. From `MANIFEST.json`, what went in and what redaction took out:

| Item | Bytes | In | Redacted |
|---|---:|---|---|
| field `title` | 68 | yes | ipv4_address 1 |
| field `what_happened` | 702 | yes | ipv4_address 2 |
| field `expected` | 128 | yes | none |
| field `not_tested` | 277 | yes | none |

### AI assistance

An AI agent drafted it, and a human checked every line

### Human review

- [ ] I'm a human, I read this whole report and I answer for it.
- [ ] I checked the redaction manifest and nothing private is left.
- [ ] I searched the issues for the fingerprint.
